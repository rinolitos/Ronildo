#|
$JSON
{"authURL":["ai2a.appinventor.mit.edu"],"YaVersion":"233","Source":"Form","Properties":{"$Name":"Tela1","$Type":"Form","$Version":"31","ActionBar":"True","AppName":"Varias_Telas","BackgroundColor":"&HFF0B0B5D","Title":"Tela1","Uuid":"0","$Components":[{"$Name":"Voltar_ao_Inicio","$Type":"Button","$Version":"7","FontSize":"22","Width":"-2","Shape":"1","Text":"Voltar ao Inicio","Uuid":"1821561169"}]}}
|#