#|
$JSON
{"authURL":["ai2a.appinventor.mit.edu"],"YaVersion":"233","Source":"Form","Properties":{"$Name":"Screen1","$Type":"Form","$Version":"31","ActionBar":"True","AppName":"Teclado","Title":"Screen1","Uuid":"0","$Components":[{"$Name":"CaixaDeTexto","$Type":"TextBox","$Version":"14","Uuid":"-426175061"},{"$Name":"Bot\u00e3o","$Type":"Button","$Version":"7","FontSize":"22","Shape":"1","Text":"Digite seu nome e clique aqui!","Uuid":"-813641250"},{"$Name":"Mostrar_Legenda","$Type":"Label","$Version":"5","FontSize":"22","Uuid":"867007877"}]}}
|#