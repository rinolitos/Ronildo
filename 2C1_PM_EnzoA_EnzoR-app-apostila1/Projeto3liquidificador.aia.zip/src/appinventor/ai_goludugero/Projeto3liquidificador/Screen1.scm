#|
$JSON
{"authURL":["ai2a.appinventor.mit.edu"],"YaVersion":"233","Source":"Form","Properties":{"$Name":"Screen1","$Type":"Form","$Version":"31","ActionBar":"True","AppName":"Projeto3liquidificador","Title":"liquidificador","Uuid":"0","$Components":[{"$Name":"Bot\u00e3o1","$Type":"Button","$Version":"7","Height":"-2","Width":"-2","Image":"liquidificador.jfif","Uuid":"-505471005"},{"$Name":"Som1","$Type":"Sound","$Version":"4","Source":"audio_liquidificador.mp3","Uuid":"1184676194"}]}}
|#